# strong_ocr_core.py
import io, time
from typing import Dict, Any, List
import fitz, numpy as np, cv2
from PIL import Image
from paddleocr import PaddleOCR

def render_page_to_rgb_arrays(pdf_bytes: bytes, dpi: int) -> List[np.ndarray]:
    arrs = []
    with fitz.open(stream=pdf_bytes, filetype="pdf") as doc:
        zoom = dpi / 72.0
        mat = fitz.Matrix(zoom, zoom)
        for p in doc:
            pix = p.get_pixmap(matrix=mat, alpha=False)
            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            arrs.append(np.array(img.convert("RGB")))
    return arrs

def adaptive_binarize(arr_rgb: np.ndarray, block_size: int, C: int) -> np.ndarray:
    gray = cv2.cvtColor(arr_rgb, cv2.COLOR_RGB2GRAY)
    if block_size % 2 == 0:
        block_size += 1
    return cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
                                 cv2.THRESH_BINARY, block_size, C)

def parse_blocks(blocks) -> List[Dict[str, Any]]:
    out = []
    for blk in (blocks or []):
        rec_texts = getattr(blk, "rec_texts", None)
        rec_scores = getattr(blk, "rec_scores", None)
        rec_boxes = getattr(blk, "rec_boxes", None)
        if rec_texts is None or rec_scores is None:
            if isinstance(blk, dict):
                rec_texts = blk.get("rec_texts", [])
                rec_scores = blk.get("rec_scores", [])
                rec_boxes = blk.get("rec_boxes", None)
        if rec_texts is None or rec_scores is None:
            continue
        n = min(len(rec_texts), len(rec_scores))
        for i in range(n):
            t = str(rec_texts[i]) if rec_texts[i] is not None else ""
            s = float(rec_scores[i]) if rec_scores[i] is not None else 0.0
            if not t:
                continue
            item = {"text": t, "score": s}
            if rec_boxes is not None and len(rec_boxes) > i:
                try:
                    item["box"] = rec_boxes[i].tolist()
                except Exception:
                    pass
            out.append(item)
    return out

class OCREngine:
    def __init__(self, lang="ch", use_textline_orientation=True):
        self.ocr = PaddleOCR(use_textline_orientation=use_textline_orientation, lang=lang)

    def ocr_array(self, arr: np.ndarray):
        if arr.ndim == 2:
            arr = cv2.cvtColor(arr, cv2.COLOR_GRAY2RGB)
        return parse_blocks(self.ocr.predict(arr))

def ocr_pdf_bytes(pdf_bytes: bytes, *, dpi=350, min_score=0.35,
                  upscale_factor=1.6, bin_block_size=35, bin_C=10,
                  lang="ch") -> Dict[str, Any]:
    engine = OCREngine(lang=lang)
    pages = []
    total_lines = 0
    arrs = render_page_to_rgb_arrays(pdf_bytes, dpi=dpi)
    for pidx, arr in enumerate(arrs):
        lines = engine.ocr_array(arr)
        if not lines and upscale_factor and upscale_factor > 1.0:
            arr_up = cv2.resize(arr, (int(arr.shape[1]*upscale_factor), int(arr.shape[0]*upscale_factor)),
                                interpolation=cv2.INTER_CUBIC)
            lines = engine.ocr_array(arr_up)
        if not lines:
            arr_bin = adaptive_binarize(arr, bin_block_size, bin_C)
            lines = engine.ocr_array(arr_bin)
        lines = [x for x in lines if x.get("score", 0) >= min_score]
        total_lines += len(lines)
        pages.append({"page_index": pidx, "lines": lines})
    full_text = "\n".join(l["text"] for p in pages for l in p["lines"])
    return {"pages": pages, "total_lines": total_lines, "full_text": full_text}

def ocr_image_bytes(img_bytes: bytes, *, min_score=0.35,
                    upscale_factor=1.6, bin_block_size=35, bin_C=10,
                    lang="ch") -> Dict[str, Any]:
    engine = OCREngine(lang=lang)
    arr = np.array(Image.open(io.BytesIO(img_bytes)).convert("RGB"))
    lines = engine.ocr_array(arr)
    if not lines and upscale_factor and upscale_factor > 1.0:
        arr_up = cv2.resize(arr, (int(arr.shape[1]*upscale_factor), int(arr.shape[0]*upscale_factor)),
                            interpolation=cv2.INTER_CUBIC)
        lines = engine.ocr_array(arr_up)
    if not lines:
        arr_bin = adaptive_binarize(arr, bin_block_size, bin_C)
        lines = engine.ocr_array(arr_bin)
    lines = [x for x in lines if x.get("score", 0) >= min_score]
    full_text = "\n".join(x["text"] for x in lines)
    return {"pages": [{"page_index": 0, "lines": lines}],
            "total_lines": len(lines), "full_text": full_text}
