# app.py
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from pydantic import BaseModel
from strong_ocr_core import ocr_pdf_bytes, ocr_image_bytes
import uvicorn  # ✅ 新增

app = FastAPI(title="OCR Service", version="1.0")

class OCRParams(BaseModel):
    dpi: int = 350
    min_score: float = 0.35
    upscale_factor: float = 1.6
    bin_block_size: int = 35
    bin_C: int = 10
    lang: str = "ch"


@app.post("/ocr/pdf:sync")
async def ocr_pdf_sync(
    file: UploadFile = File(...),
    dpi: int = Form(350),
    min_score: float = Form(0.35),
    upscale_factor: float = Form(1.6),
    bin_block_size: int = Form(35),
    bin_C: int = Form(10),
    lang: str = Form("ch"),
):
    if file.content_type not in ("application/pdf", "application/octet-stream"):
        raise HTTPException(400, "content_type 必须是 application/pdf")
    pdf_bytes = await file.read()
    result = ocr_pdf_bytes(
        pdf_bytes,
        dpi=dpi, min_score=min_score, upscale_factor=upscale_factor,
        bin_block_size=bin_block_size, bin_C=bin_C, lang=lang,
    )
    return {"status": "ok", **result}


@app.post("/ocr/image:sync")
async def ocr_image_sync(
    file: UploadFile = File(...),
    min_score: float = Form(0.35),
    upscale_factor: float = Form(1.6),
    bin_block_size: int = Form(35),
    bin_C: int = Form(10),
    lang: str = Form("ch"),
):
    if not file.content_type.startswith("image/"):
        raise HTTPException(400, "content_type 必须是 image/*")
    img_bytes = await file.read()
    result = ocr_image_bytes(
        img_bytes,
        min_score=min_score, upscale_factor=upscale_factor,
        bin_block_size=bin_block_size, bin_C=bin_C, lang=lang,
    )
    return {"status": "ok", **result}


@app.get("/healthz")
def healthz():
    return {"status": "ok"}


# ✅ 显式启动入口
if __name__ == "__main__":
    # 默认绑定 0.0.0.0，端口 8080
    uvicorn.run("app:app", host="0.0.0.0", port=8181, reload=True)
